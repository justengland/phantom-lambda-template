console.log('Hello from phantom');
phantom.exit();